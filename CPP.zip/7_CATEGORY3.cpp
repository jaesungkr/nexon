
#include <iostream>


template<typename IT, typename T>
IT find(IT first, IT last, const T& c)
{
	while (first != last && *first != c)
		++first;

	return first;
}

int main()
{
	double x[10] = { 1,2,3,4,5,6,7,8,9,10 };

	double* p = find(x, x + 3, 5.0f);

}