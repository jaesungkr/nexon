#include <iostream>
#include <string>
#include <vector>

class People
{
private:
	std::string name;

public:
	People(std::string s) : name(s) {}  
};

int main()
{
	std::string s1 = "KIM";
	std::string s2 = "LEE";

	People p1(s1);
	People p2( std::move(s2) );

	std::cout << s1 << std::endl;
	std::cout << s2 << std::endl;
}



