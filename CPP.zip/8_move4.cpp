#include <iostream>
#include <string>
#include <vector>

class Machine
{
	std::string data;
public:
	// setter �����
	void setData(const std::string& s) { data = s; }
};

int main()
{
	std::string s1 = "AAA";
	std::string s2 = "BBB";

	Machine m;
	m.setData(s1);				
	m.setData(std::move(s2));	


	std::vector<std::string> v;

	v.push_back(s1);
	v.push_back(std::move(s2));
}

