﻿#include <iostream>
#include <vector>
#include <list>
#include <forward_list>
#include <algorithm>

// 반복자의 5가지 분류(category) 

// 입력 반복자     : =*p, ++
// 출력 반복자     : *p=, ++
//-----------------아래 3개는 멀티 패스를 보장합니다. ----------------
// 전진형 반복자   : =*p, ++					싱글리스트의 반복자
// 양방향 반복자   : =*p, ++, --				더블리스트의 반복자
// 임의접근 반복자 : =*p, ++, --, +, -, []  연속된 메모리와 유사한 컨테이너의 반복자
//											vector, deque											
int main()
{
	std::forward_list<int> s1 = { 1,2,3 };
	std::list<int> s2 = { 1,2,3 };
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10 };

	// find 알고리즘은 1, 2번째 인자가 반복자 입니다. 
	// 최소 요구 조건을 5개의 분류에서 골라 보세요. 
	auto p = std::find(std::begin(v), std::end(v), 5);

}







