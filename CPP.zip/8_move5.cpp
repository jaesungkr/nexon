#include <iostream>
#include <string>
#include <type_traits>

template<typename T, typename U> struct Pair
{
	T first;
	U second;

	// Pair ������ �����
};

int main()
{
	Pair<int, double> p1(1, 3.4);

	std::string s1 = "AAA";
	std::string s1 = "BBB";

	Pair<std::string, std::string> p2(s1, s2);
}