#include <iostream>
#include <string>
#include <vector>

template<typename T> 
void Swap(T& a, T& b)
{
	T tmp = a;
	a = b;
	b = tmp;
}

int main()
{
	std::string s1 = "AAAA";
	std::string s2 = "BBBB";

	Swap(s1, s2);
}



