﻿using System;

class Point   // reference type
{
    public int x = 0;
    public int y = 0;

    public Point(int a, int b) { x = a; y = b; }

}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(1, 1);
        Point p2 = new Point(1, 1);

        Console.WriteLine(p1 == p2);

        Console.WriteLine(p1.Equals(p2));
    }
}
