﻿using System;


struct Point 
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }

}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(1, 1);
        
        // p1, p2 객체의 크기를 비교 하고 싶다.

    }
}









