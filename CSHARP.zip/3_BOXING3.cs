﻿using System;

struct Point
{
    public int x;
    public int y;
    public Point(int a = 0, int b = 0) { x = a; y = b; }

    public override bool Equals(object obj)
    {
        Point pt = (Point)obj;
        return x == pt.x;
    }
}

class Program
{
    public static void Main()
    {
        Point p1 = new Point(0, 0);
        Point p2 = new Point(0, 1);

        if (p1.Equals(p2))
        {
            Console.WriteLine("Same");
        }
        else
            Console.WriteLine("not Same");

    }
}