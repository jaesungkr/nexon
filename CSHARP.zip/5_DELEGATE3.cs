﻿using System;

class Button
{

    public void Press()
    {
        // 여기서 일을 하게 되면 모든 버튼은 동일한 일을 하게된다.
        // 버튼이 눌린사실을 외부에 알려야 한다.
    }
}

class Program
{
    public static void OnClick() { Console.WriteLine("Button Click"); }
    public static void Main()
    {
        Button b1 = new Button();
        Button b2 = new Button();

        b1.Press();
    }
}
