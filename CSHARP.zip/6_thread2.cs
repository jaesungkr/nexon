﻿using System;
using System.Threading;

class Program
{
    public static void F1()             { Console.WriteLine($"F1"); }
    public static void F2(object obj)   { Console.WriteLine($"F3 : {obj.ToString()}"); }
    public static void F3(string msg)   { Console.WriteLine($"F4 : {msg}"); }
    public static void F4(int a, int b) { Console.WriteLine($"F5 : {a}, {b}"); }

    public static void Main()
    {
        Thread t1 = new Thread(F1);
        t1.Start();

    }
}