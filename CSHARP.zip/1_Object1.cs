﻿using System;

// 핵심 1. 모든 것은 객체이다.

class Program
{
    public static void Main()
    {
        
    }
}