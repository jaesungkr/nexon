﻿using System;

// 핵심: value_type vs reference type

// C/C++ 언어를 생각해 봅시다.

//Point p1(1,2);
//Point* p2 = new Point(1, 2);

class CPoint   
{
    public int x;
    public int y;
}

class Program
{
    public static void Main()
    {
    }
}