﻿using System;



class Program
{
    public static void F1() { Console.WriteLine("F1"); }
    public static void F2(int a) { Console.WriteLine("F2"); }
    public static void F3(int a, double b) { Console.WriteLine("F3"); }

    public static int F4() { Console.WriteLine("F4"); return 0; }
    public static double F5() { Console.WriteLine("F5"); return 0; }
    public static double F6(string s) { Console.WriteLine("F6"); return 0; }

    public static void Main()
    {
        ? a1 = F1;
    }


}

