﻿using System;

// value_type 과 reference_type 조사
// C
//int n;
//int x[3];

class Program
{
    public static void Main()
    {
        // C# 배열 만들기
        // 배열은 value type 일까요 ? reference type 일까요?
        int[] x = new int[] { 1, 2, 3, 4, 5 };
        int[] y = x;

        x[0] = 10;

        Console.WriteLine($"{y[0]}");  // 결과는 ?

    }
}





