﻿using System;

// Multicast Delegate, reference type, immutable
delegate void FP(int a);

class Program
{
    public static void Foo(int a) { Console.WriteLine($"Foo : {a}"); }
    public static void Goo(int a) { Console.WriteLine($"Goo : {a}"); }
    public void Hoo(int a) { Console.WriteLine($"Hoo : {a}"); }

    public static void Main()
    {
        // 1. 델리게이트에는 여러개 함수 등록 가능.
        FP f = Foo;         // static 메소드 등록 방법 1. 함수이름
        f += Program.Goo;   // static 메소드 등록 방법 2. 클래스이름.함수이름


    }
}








