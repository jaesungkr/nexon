﻿using System;

class Program
{
    public static void Foo(int a) { }

    public static void Main()
    {
        int n = 10;     // 10은 int 타입
        double d = 3.4; // 3.4 는 double 타입

        ? f = Foo; 
    }
}



