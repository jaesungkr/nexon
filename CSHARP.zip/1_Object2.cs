﻿using System;

class Car
{
}

class Program
{
    public static void Main()
    {
        Car c = new Car();
    }

    public static void Foo(object o)
    {
        int n;
        string s = o.ToString();
        Console.WriteLine(s);
    }
}